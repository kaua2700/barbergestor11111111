
document.getElementById("form-agendamento").addEventListener("submit", function(e) {
  e.preventDefault();

  const cliente = document.getElementById("cliente").value;
  const dataHora = document.getElementById("dataHora").value;
  const servico = document.getElementById("servico").value;

  const agendamento = { cliente, dataHora, servico };

  let agendamentos = JSON.parse(localStorage.getItem("agendamentos")) || [];
  agendamentos.push(agendamento);
  localStorage.setItem("agendamentos", JSON.stringify(agendamentos));

  listarAgendamentos();
});

function listarAgendamentos() {
  const lista = document.getElementById("lista-agendamentos");
  lista.innerHTML = "";

  const agendamentos = JSON.parse(localStorage.getItem("agendamentos")) || [];

  agendamentos.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = `${item.dataHora} - ${item.cliente} (${item.servico})`;
    lista.appendChild(li);
  });
}

listarAgendamentos();
